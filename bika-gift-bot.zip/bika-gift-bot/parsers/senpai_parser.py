from __future__ import annotations

import re

_SENPAI_ID_RE = re.compile(r"🆔\s*[:#]?\s*(\d+)", re.IGNORECASE)


def parse_senpai_ids(text: str) -> list[int]:
    """Extract ordered unique IDs that follow the SenpaiCatcher ID emoji."""
    seen: set[int] = set()
    result: list[int] = []
    for match in _SENPAI_ID_RE.finditer(text or ""):
        value = int(match.group(1))
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result
